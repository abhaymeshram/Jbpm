package com.drools.rulesengine.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.drools.rulesengine.models.InvoiceDataModel;
import com.drools.rulesengine.models.RulesDataModel;
import com.drools.rulesengine.service.RuleService;

@RestController
public class RulesRestController {
	
	@Autowired
	RuleService ruleService;

	@PostMapping("/applyRules/modules")
	public RulesDataModel applyRules(@RequestBody RulesDataModel rulesDataModel) throws Exception {
		System.out.println("I am in apply rules");
		return ruleService.applyRules(rulesDataModel);
	}
	
	@PostMapping("/applyRules/invoice")
	public InvoiceDataModel applyInvoiceRules(@RequestBody InvoiceDataModel invoiceDataModel) throws Exception {
		System.out.println("I am in apply rules");
		return ruleService.applyInvoiceRules(invoiceDataModel);
	}
	
	@GetMapping("/update")
	public String updateRules() throws Exception {
		return ruleService.updateRules();
	}
}
