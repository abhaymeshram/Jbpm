# Spring Boot - Multiple Datasources
An example how to configure multiple datasources in a Spring Boot application

# My related Medium blog posts:
* [Using multiple datasources with Spring Boot and Spring Data 💈 ⇄ 🌱 ⇄ 💈](https://medium.com/@joeclever/using-multiple-datasources-with-spring-boot-and-spring-data-6430b00c02e7 "Using multiple datasources with Spring Boot and Spring Data")
* [Integration Testing multiple datasources in Spring Boot and Spring Data with Spock 🎯](https://medium.com/@joeclever/integration-testing-multiple-datasources-in-spring-boot-and-spring-data-with-spock-f88e1428ce9f "Integration Testing multiple datasources in Spring Boot and Spring Data with Spock")
