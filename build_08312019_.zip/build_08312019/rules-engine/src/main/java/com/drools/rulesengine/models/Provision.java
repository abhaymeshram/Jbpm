package com.drools.rulesengine.models;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Provision implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private float provision_assessment_year;
	private String provision_withholding_section;
	private String deductor_master_tan;
	private float provision_assessment_month;
	private boolean provision_mismatch;
	private String provision_id;
	private String batch_upload_id = null;
	private String provision_account_code = null;
	private boolean provision_active;
	private String provision_company_code = null;
	private String provision_created_by = null;
	private String provision_created_date = null;
	private String provision_dedcutor_gstin = null;
	private String provision_deductee_code = null;
	private String provision_deductee_gstin = null;
	private String provision_deductee_name = null;
	private boolean provision_deductee_non_resident_indicator;
	private String provision_deductee_pan = null;
	private String provision_deductee_tin = null;
	private String provision_deductor_pan = null;
	private String provision_deductor_tan = null;
	private String provision_derived_tds_amount = null;
	private String provision_derived_tds_rate = null;
	private String provision_derived_tds_section = null;
	private String provision_description = null;
	private String provision_document_date = null;
	private String provision_document_number = null;
	private String provision_document_type = null;
	private String provision_entry_date = null;
	private double provision_final_tds_amount;
	private String provision_final_tds_rate = null;
	private String provision_final_tds_section = null;
	private String provision_hsn_or_sacc = null;
	private String provision_hsnsac_description = null;
	private String provision_line_item_number = null;
	private String provision_linking_invoice_po = null;
	private String provision_modified_by = null;
	private String provision_modified_date = null;
	private String provision_place_of_supply = null;
	private String provision_po_date = null;
	private String provision_po_number = null;
	private String provision_po_type = null;
	private String provision_pos = null;
	private String provision_posting_date_of_document = null;
	private String provision_provisional_amount = null;
	private String provision_section_code = null;
	private String provision_service_description = null;
	private String provision_service_description_gl = null;
	private String provision_service_description_po = null;
	private String provision_source_file_name = null;
	private String provision_source_identifier = null;
	private String provision_user_defined_field_1 = null;
	private String provision_user_defined_field_2 = null;
	private String provision_user_defined_field_3 = null;
	private String provision_withholding_amount = null;
	private String provision_withholding_rate = null;
	private String provision_account_description = null;
	private String provision_name_of_the_company_code = null;
	private String provision_mismatch_category = null;

	// Getter Methods

	public float getProvision_assessment_year() {
		return provision_assessment_year;
	}

	public String getProvision_withholding_section() {
		return provision_withholding_section;
	}

	public String getDeductor_master_tan() {
		return deductor_master_tan;
	}

	public float getProvision_assessment_month() {
		return provision_assessment_month;
	}

	public boolean getProvision_mismatch() {
		return provision_mismatch;
	}

	public String getProvision_id() {
		return provision_id;
	}

	public String getBatch_upload_id() {
		return batch_upload_id;
	}

	public String getProvision_account_code() {
		return provision_account_code;
	}

	public boolean getProvision_active() {
		return provision_active;
	}

	public String getProvision_company_code() {
		return provision_company_code;
	}

	public String getProvision_created_by() {
		return provision_created_by;
	}

	public String getProvision_created_date() {
		return provision_created_date;
	}

	public String getProvision_dedcutor_gstin() {
		return provision_dedcutor_gstin;
	}

	public String getProvision_deductee_code() {
		return provision_deductee_code;
	}

	public String getProvision_deductee_gstin() {
		return provision_deductee_gstin;
	}

	public String getProvision_deductee_name() {
		return provision_deductee_name;
	}

	public boolean getProvision_deductee_non_resident_indicator() {
		return provision_deductee_non_resident_indicator;
	}

	public String getProvision_deductee_pan() {
		return provision_deductee_pan;
	}

	public String getProvision_deductee_tin() {
		return provision_deductee_tin;
	}

	public String getProvision_deductor_pan() {
		return provision_deductor_pan;
	}

	public String getProvision_deductor_tan() {
		return provision_deductor_tan;
	}

	public String getProvision_derived_tds_amount() {
		return provision_derived_tds_amount;
	}

	public String getProvision_derived_tds_rate() {
		return provision_derived_tds_rate;
	}

	public String getProvision_derived_tds_section() {
		return provision_derived_tds_section;
	}

	public String getProvision_description() {
		return provision_description;
	}

	public String getProvision_document_date() {
		return provision_document_date;
	}

	public String getProvision_document_number() {
		return provision_document_number;
	}

	public String getProvision_document_type() {
		return provision_document_type;
	}

	public String getProvision_entry_date() {
		return provision_entry_date;
	}

	public double getProvision_final_tds_amount() {
		return provision_final_tds_amount;
	}

	public String getProvision_final_tds_rate() {
		return provision_final_tds_rate;
	}

	public String getProvision_final_tds_section() {
		return provision_final_tds_section;
	}

	public String getProvision_hsn_or_sacc() {
		return provision_hsn_or_sacc;
	}

	public String getProvision_hsnsac_description() {
		return provision_hsnsac_description;
	}

	public String getProvision_line_item_number() {
		return provision_line_item_number;
	}

	public String getProvision_linking_invoice_po() {
		return provision_linking_invoice_po;
	}

	public String getProvision_modified_by() {
		return provision_modified_by;
	}

	public String getProvision_modified_date() {
		return provision_modified_date;
	}

	public String getProvision_place_of_supply() {
		return provision_place_of_supply;
	}

	public String getProvision_po_date() {
		return provision_po_date;
	}

	public String getProvision_po_number() {
		return provision_po_number;
	}

	public String getProvision_po_type() {
		return provision_po_type;
	}

	public String getProvision_pos() {
		return provision_pos;
	}

	public String getProvision_posting_date_of_document() {
		return provision_posting_date_of_document;
	}

	public String getProvision_provisional_amount() {
		return provision_provisional_amount;
	}

	public String getProvision_section_code() {
		return provision_section_code;
	}

	public String getProvision_service_description() {
		return provision_service_description;
	}

	public String getProvision_service_description_gl() {
		return provision_service_description_gl;
	}

	public String getProvision_service_description_po() {
		return provision_service_description_po;
	}

	public String getProvision_source_file_name() {
		return provision_source_file_name;
	}

	public String getProvision_source_identifier() {
		return provision_source_identifier;
	}

	public String getProvision_user_defined_field_1() {
		return provision_user_defined_field_1;
	}

	public String getProvision_user_defined_field_2() {
		return provision_user_defined_field_2;
	}

	public String getProvision_user_defined_field_3() {
		return provision_user_defined_field_3;
	}

	public String getProvision_withholding_amount() {
		return provision_withholding_amount;
	}

	public String getProvision_withholding_rate() {
		return provision_withholding_rate;
	}

	public String getProvision_account_description() {
		return provision_account_description;
	}

	public String getProvision_name_of_the_company_code() {
		return provision_name_of_the_company_code;
	}

	public String getProvision_mismatch_category() {
		return provision_mismatch_category;
	}

	// Setter Methods

	public void setProvision_assessment_year(float provision_assessment_year) {
		this.provision_assessment_year = provision_assessment_year;
	}

	public void setProvision_withholding_section(String provision_withholding_section) {
		this.provision_withholding_section = provision_withholding_section;
	}

	public void setDeductor_master_tan(String deductor_master_tan) {
		this.deductor_master_tan = deductor_master_tan;
	}

	public void setProvision_assessment_month(float provision_assessment_month) {
		this.provision_assessment_month = provision_assessment_month;
	}

	public void setProvision_mismatch(boolean provision_mismatch) {
		this.provision_mismatch = provision_mismatch;
	}

	public void setProvision_id(String provision_id) {
		this.provision_id = provision_id;
	}

	public void setBatch_upload_id(String batch_upload_id) {
		this.batch_upload_id = batch_upload_id;
	}

	public void setProvision_account_code(String provision_account_code) {
		this.provision_account_code = provision_account_code;
	}

	public void setProvision_active(boolean provision_active) {
		this.provision_active = provision_active;
	}

	public void setProvision_company_code(String provision_company_code) {
		this.provision_company_code = provision_company_code;
	}

	public void setProvision_created_by(String provision_created_by) {
		this.provision_created_by = provision_created_by;
	}

	public void setProvision_created_date(String provision_created_date) {
		this.provision_created_date = provision_created_date;
	}

	public void setProvision_dedcutor_gstin(String provision_dedcutor_gstin) {
		this.provision_dedcutor_gstin = provision_dedcutor_gstin;
	}

	public void setProvision_deductee_code(String provision_deductee_code) {
		this.provision_deductee_code = provision_deductee_code;
	}

	public void setProvision_deductee_gstin(String provision_deductee_gstin) {
		this.provision_deductee_gstin = provision_deductee_gstin;
	}

	public void setProvision_deductee_name(String provision_deductee_name) {
		this.provision_deductee_name = provision_deductee_name;
	}

	public void setProvision_deductee_non_resident_indicator(boolean provision_deductee_non_resident_indicator) {
		this.provision_deductee_non_resident_indicator = provision_deductee_non_resident_indicator;
	}

	public void setProvision_deductee_pan(String provision_deductee_pan) {
		this.provision_deductee_pan = provision_deductee_pan;
	}

	public void setProvision_deductee_tin(String provision_deductee_tin) {
		this.provision_deductee_tin = provision_deductee_tin;
	}

	public void setProvision_deductor_pan(String provision_deductor_pan) {
		this.provision_deductor_pan = provision_deductor_pan;
	}

	public void setProvision_deductor_tan(String provision_deductor_tan) {
		this.provision_deductor_tan = provision_deductor_tan;
	}

	public void setProvision_derived_tds_amount(String provision_derived_tds_amount) {
		this.provision_derived_tds_amount = provision_derived_tds_amount;
	}

	public void setProvision_derived_tds_rate(String provision_derived_tds_rate) {
		this.provision_derived_tds_rate = provision_derived_tds_rate;
	}

	public void setProvision_derived_tds_section(String provision_derived_tds_section) {
		this.provision_derived_tds_section = provision_derived_tds_section;
	}

	public void setProvision_description(String provision_description) {
		this.provision_description = provision_description;
	}

	public void setProvision_document_date(String provision_document_date) {
		this.provision_document_date = provision_document_date;
	}

	public void setProvision_document_number(String provision_document_number) {
		this.provision_document_number = provision_document_number;
	}

	public void setProvision_document_type(String provision_document_type) {
		this.provision_document_type = provision_document_type;
	}

	public void setProvision_entry_date(String provision_entry_date) {
		this.provision_entry_date = provision_entry_date;
	}

	public void setProvision_final_tds_amount(double provision_final_tds_amount) {
		this.provision_final_tds_amount = provision_final_tds_amount;
	}

	public void setProvision_final_tds_rate(String provision_final_tds_rate) {
		this.provision_final_tds_rate = provision_final_tds_rate;
	}

	public void setProvision_final_tds_section(String provision_final_tds_section) {
		this.provision_final_tds_section = provision_final_tds_section;
	}

	public void setProvision_hsn_or_sacc(String provision_hsn_or_sacc) {
		this.provision_hsn_or_sacc = provision_hsn_or_sacc;
	}

	public void setProvision_hsnsac_description(String provision_hsnsac_description) {
		this.provision_hsnsac_description = provision_hsnsac_description;
	}

	public void setProvision_line_item_number(String provision_line_item_number) {
		this.provision_line_item_number = provision_line_item_number;
	}

	public void setProvision_linking_invoice_po(String provision_linking_invoice_po) {
		this.provision_linking_invoice_po = provision_linking_invoice_po;
	}

	public void setProvision_modified_by(String provision_modified_by) {
		this.provision_modified_by = provision_modified_by;
	}

	public void setProvision_modified_date(String provision_modified_date) {
		this.provision_modified_date = provision_modified_date;
	}

	public void setProvision_place_of_supply(String provision_place_of_supply) {
		this.provision_place_of_supply = provision_place_of_supply;
	}

	public void setProvision_po_date(String provision_po_date) {
		this.provision_po_date = provision_po_date;
	}

	public void setProvision_po_number(String provision_po_number) {
		this.provision_po_number = provision_po_number;
	}

	public void setProvision_po_type(String provision_po_type) {
		this.provision_po_type = provision_po_type;
	}

	public void setProvision_pos(String provision_pos) {
		this.provision_pos = provision_pos;
	}

	public void setProvision_posting_date_of_document(String provision_posting_date_of_document) {
		this.provision_posting_date_of_document = provision_posting_date_of_document;
	}

	public void setProvision_provisional_amount(String provision_provisional_amount) {
		this.provision_provisional_amount = provision_provisional_amount;
	}

	public void setProvision_section_code(String provision_section_code) {
		this.provision_section_code = provision_section_code;
	}

	public void setProvision_service_description(String provision_service_description) {
		this.provision_service_description = provision_service_description;
	}

	public void setProvision_service_description_gl(String provision_service_description_gl) {
		this.provision_service_description_gl = provision_service_description_gl;
	}

	public void setProvision_service_description_po(String provision_service_description_po) {
		this.provision_service_description_po = provision_service_description_po;
	}

	public void setProvision_source_file_name(String provision_source_file_name) {
		this.provision_source_file_name = provision_source_file_name;
	}

	public void setProvision_source_identifier(String provision_source_identifier) {
		this.provision_source_identifier = provision_source_identifier;
	}

	public void setProvision_user_defined_field_1(String provision_user_defined_field_1) {
		this.provision_user_defined_field_1 = provision_user_defined_field_1;
	}

	public void setProvision_user_defined_field_2(String provision_user_defined_field_2) {
		this.provision_user_defined_field_2 = provision_user_defined_field_2;
	}

	public void setProvision_user_defined_field_3(String provision_user_defined_field_3) {
		this.provision_user_defined_field_3 = provision_user_defined_field_3;
	}

	public void setProvision_withholding_amount(String provision_withholding_amount) {
		this.provision_withholding_amount = provision_withholding_amount;
	}

	public void setProvision_withholding_rate(String provision_withholding_rate) {
		this.provision_withholding_rate = provision_withholding_rate;
	}

	public void setProvision_account_description(String provision_account_description) {
		this.provision_account_description = provision_account_description;
	}

	public void setProvision_name_of_the_company_code(String provision_name_of_the_company_code) {
		this.provision_name_of_the_company_code = provision_name_of_the_company_code;
	}

	public void setProvision_mismatch_category(String provision_mismatch_category) {
		this.provision_mismatch_category = provision_mismatch_category;
	}

	@Override
	public String toString() {
		return "Provision [provision_assessment_year=" + provision_assessment_year + ", provision_withholding_section="
				+ provision_withholding_section + ", deductor_master_tan=" + deductor_master_tan
				+ ", provision_assessment_month=" + provision_assessment_month + ", provision_mismatch="
				+ provision_mismatch + ", provision_id=" + provision_id + ", batch_upload_id=" + batch_upload_id
				+ ", provision_account_code=" + provision_account_code + ", provision_active=" + provision_active
				+ ", provision_company_code=" + provision_company_code + ", provision_created_by="
				+ provision_created_by + ", provision_created_date=" + provision_created_date
				+ ", provision_dedcutor_gstin=" + provision_dedcutor_gstin + ", provision_deductee_code="
				+ provision_deductee_code + ", provision_deductee_gstin=" + provision_deductee_gstin
				+ ", provision_deductee_name=" + provision_deductee_name
				+ ", provision_deductee_non_resident_indicator=" + provision_deductee_non_resident_indicator
				+ ", provision_deductee_pan=" + provision_deductee_pan + ", provision_deductee_tin="
				+ provision_deductee_tin + ", provision_deductor_pan=" + provision_deductor_pan
				+ ", provision_deductor_tan=" + provision_deductor_tan + ", provision_derived_tds_amount="
				+ provision_derived_tds_amount + ", provision_derived_tds_rate=" + provision_derived_tds_rate
				+ ", provision_derived_tds_section=" + provision_derived_tds_section + ", provision_description="
				+ provision_description + ", provision_document_date=" + provision_document_date
				+ ", provision_document_number=" + provision_document_number + ", provision_document_type="
				+ provision_document_type + ", provision_entry_date=" + provision_entry_date
				+ ", provision_final_tds_amount=" + provision_final_tds_amount + ", provision_final_tds_rate="
				+ provision_final_tds_rate + ", provision_final_tds_section=" + provision_final_tds_section
				+ ", provision_hsn_or_sacc=" + provision_hsn_or_sacc + ", provision_hsnsac_description="
				+ provision_hsnsac_description + ", provision_line_item_number=" + provision_line_item_number
				+ ", provision_linking_invoice_po=" + provision_linking_invoice_po + ", provision_modified_by="
				+ provision_modified_by + ", provision_modified_date=" + provision_modified_date
				+ ", provision_place_of_supply=" + provision_place_of_supply + ", provision_po_date="
				+ provision_po_date + ", provision_po_number=" + provision_po_number + ", provision_po_type="
				+ provision_po_type + ", provision_pos=" + provision_pos + ", provision_posting_date_of_document="
				+ provision_posting_date_of_document + ", provision_provisional_amount=" + provision_provisional_amount
				+ ", provision_section_code=" + provision_section_code + ", provision_service_description="
				+ provision_service_description + ", provision_service_description_gl="
				+ provision_service_description_gl + ", provision_service_description_po="
				+ provision_service_description_po + ", provision_source_file_name=" + provision_source_file_name
				+ ", provision_source_identifier=" + provision_source_identifier + ", provision_user_defined_field_1="
				+ provision_user_defined_field_1 + ", provision_user_defined_field_2=" + provision_user_defined_field_2
				+ ", provision_user_defined_field_3=" + provision_user_defined_field_3
				+ ", provision_withholding_amount=" + provision_withholding_amount + ", provision_withholding_rate="
				+ provision_withholding_rate + ", provision_account_description=" + provision_account_description
				+ ", provision_name_of_the_company_code=" + provision_name_of_the_company_code
				+ ", provision_mismatch_category=" + provision_mismatch_category + "]";
	}
	
	
}