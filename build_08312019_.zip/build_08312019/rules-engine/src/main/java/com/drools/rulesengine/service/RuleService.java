package com.drools.rulesengine.service;

import com.drools.rulesengine.models.InvoiceDataModel;
import com.drools.rulesengine.models.RulesDataModel;

	public interface RuleService {

		RulesDataModel applyRules(RulesDataModel rulesDataModel) throws Exception;
		String updateRules() throws Exception;
		public InvoiceDataModel applyInvoiceRules(InvoiceDataModel invoiceDataModel) throws Exception;
	}
