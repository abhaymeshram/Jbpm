package com.drools.rulesengine.models;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Invoice implements Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private double invoice_line_item_invoice_amount;
	private double invoice_line_item_tds_amount;
	private double invoice_line_item_tds_rate;
	private String invoice_advance_deductee_pan;
	private String invoice_line_item_actual_tds_section;
	private boolean advanceMatched;

	public boolean isAdvanceMatched() {
		return advanceMatched;
	}

	public void setAdvanceMatched(boolean advanceMatched) {
		this.advanceMatched = advanceMatched;
	}

	public String getInvoice_advance_deductee_pan() {
		return invoice_advance_deductee_pan;
	}

	public void setInvoice_advance_deductee_pan(String invoice_advance_deductee_pan) {
		this.invoice_advance_deductee_pan = invoice_advance_deductee_pan;
	}

	public String getInvoice_line_item_actual_tds_section() {
		return invoice_line_item_actual_tds_section;
	}

	public void setInvoice_line_item_actual_tds_section(String invoice_line_item_actual_tds_section) {
		this.invoice_line_item_actual_tds_section = invoice_line_item_actual_tds_section;
	}

	public double getInvoice_line_item_invoice_amount() {
		return invoice_line_item_invoice_amount;
	}

	public void setInvoice_line_item_invoice_amount(double invoice_line_item_invoice_amount) {
		this.invoice_line_item_invoice_amount = invoice_line_item_invoice_amount;
	}

	public double getInvoice_line_item_tds_amount() {
		return invoice_line_item_tds_amount;
	}

	public void setInvoice_line_item_tds_amount(double invoice_line_item_tds_amount) {
		this.invoice_line_item_tds_amount = invoice_line_item_tds_amount;
	}

	public double getInvoice_line_item_tds_rate() {
		return invoice_line_item_tds_rate;
	}

	public void setInvoice_line_item_tds_rate(double invoice_line_item_tds_rate) {
		this.invoice_line_item_tds_rate = invoice_line_item_tds_rate;
	}

	@Override
	public Invoice clone() throws CloneNotSupportedException {
		return (Invoice) super.clone();
	}

	@Override
	public String toString() {
		return "Invoice{" +
				"invoice_line_item_invoice_amount=" + invoice_line_item_invoice_amount +
				", invoice_line_item_tds_amount=" + invoice_line_item_tds_amount +
				", invoice_line_item_tds_rate=" + invoice_line_item_tds_rate +
				", invoice_advance_deductee_pan='" + invoice_advance_deductee_pan + '\'' +
				", invoice_line_item_actual_tds_section='" + invoice_line_item_actual_tds_section + '\'' +
				", advanceMatched=" + advanceMatched +
				'}';
	}
}