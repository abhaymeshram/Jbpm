# Spring Security with JWT

Example API backend secured with Json web tokens. You can find more info in my [blog](https://jakublesko.com/spring-security-with-jwt/).
