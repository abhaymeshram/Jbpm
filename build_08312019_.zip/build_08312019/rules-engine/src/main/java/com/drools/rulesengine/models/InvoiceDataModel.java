package com.drools.rulesengine.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class InvoiceDataModel implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private List<Invoice> invoices = new ArrayList<Invoice>();
	private Invoice invoice;
	private LDC ldc;
	private List<Advance> advances;
	private Provision provision;
	private double tdcRate;
	private boolean advanceItemMatched;
	private List<Double> tds = new LinkedList<Double>();

	public List<Invoice> getInvoices() {
		return invoices;
	}

	public void setInvoices(List<Invoice> invoices) {
		this.invoices = invoices;
	}

	public Invoice getInvoice() {
		return invoice;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	public LDC getLdc() {
		return ldc;
	}

	public void setLdc(LDC ldc) {
		this.ldc = ldc;
	}

	public List<Advance> getAdvances() {
		return advances;
	}

	public void setAdvances(List<Advance> advances) {
		this.advances = advances;
	}

	public Provision getProvision() {
		return provision;
	}

	public void setProvision(Provision provision) {
		this.provision = provision;
	}

	public double getTdcRate() {
		return tdcRate;
	}

	public void setTdcRate(double tdcRate) {
		this.tdcRate = tdcRate;
	}

	public boolean isAdvanceItemMatched() {
		return advanceItemMatched;
	}

	public void setAdvanceItemMatched(boolean advanceItemMatched) {
		this.advanceItemMatched = advanceItemMatched;
	}

	public List<Double> getTds() {
		return tds;
	}

	public void setTds(List<Double> tds) {
		this.tds = tds;
	}

	@Override
	public String toString() {
		return "InvoiceDataModel [invoices=" + invoices + ", invoice=" + invoice + ", ldc=" + ldc + ", advances="
				+ advances + ", provision=" + provision + ", tdcRate=" + tdcRate + ", advanceItemMatched="
				+ advanceItemMatched + ", tds=" + tds + "]";
	}

	public void splitInvoices(final List<Double> totalTds) {
		System.out.println("LDC");
		try {
			Invoice invoiceLdc1 = this.invoice.clone();
			invoiceLdc1.setInvoice_line_item_tds_amount(totalTds.get(0));
			invoiceLdc1.setInvoice_line_item_tds_rate(this.ldc.getLdc_final_tds_rate());
			Invoice invoiceLdc2 = this.invoice.clone();
			invoiceLdc2.setInvoice_line_item_tds_amount(totalTds.get(1));
			invoices.add(invoiceLdc1);
			invoices.add(invoiceLdc2);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}

	}

	public void checkAdvanceDeducteeAndAdvanceSection(InvoiceDataModel invoiceDataModel) {
		System.out.println("INVOICE");
		if (invoiceDataModel == null || invoiceDataModel.getAdvances() == null
				|| invoiceDataModel.getAdvances().size() == 0 || invoiceDataModel.getInvoices() == null
				|| invoiceDataModel.getInvoices().size() == 0) {
			System.out.print("Invalid Input.");
		}else {
			for (Advance advance : invoiceDataModel.getAdvances()) {
				for (Invoice invoice : invoiceDataModel.getInvoices()) {
					System.out.println("Advance Deductee Pan: " + advance.getAdvance_deductee_pan());
					System.out.println("Advance Deductee Section: " + advance.getAdvance_section());
					System.out.println("Invoice Section: " + invoice.getInvoice_line_item_actual_tds_section());
					System.out.println("Invoice Section: " + invoice.getInvoice_line_item_actual_tds_section());
					System.out.println("Invoice line item actual tds section: "
							+ invoice.getInvoice_line_item_actual_tds_section());
					if (advance.getAdvance_deductee_pan() != null
							&& advance.getAdvance_deductee_pan()
									.equalsIgnoreCase(invoice.getInvoice_advance_deductee_pan())
							&& advance.getAdvance_section() != null && advance.getAdvance_section()
									.equalsIgnoreCase(invoice.getInvoice_line_item_actual_tds_section())) {
						if (advance.getAdvance_amount() == invoice.getInvoice_line_item_tds_amount()) {
							invoice.setAdvanceMatched(Boolean.TRUE);
							break;
						} else if ((advance.getAdvance_amount() < invoice.getInvoice_line_item_tds_amount()) && !invoice.isAdvanceMatched()) {
							try {
								Invoice invoiceLdc1 = invoice.clone();
								invoiceLdc1.setInvoice_line_item_tds_amount(advance.getAdvance_amount());
								invoiceLdc1.setAdvanceMatched(Boolean.TRUE);
								Invoice invoiceLdc2 = invoice.clone();
								invoiceLdc2.setInvoice_line_item_tds_amount(
										invoice.getInvoice_line_item_tds_amount() - advance.getAdvance_amount());
								invoiceDataModel.getInvoices().add(invoiceLdc1);
								invoiceDataModel.getInvoices().add(invoiceLdc2);
								break;
							} catch (CloneNotSupportedException e) {
								e.printStackTrace();
							}
						}
						System.out.println("Advance Amount: " + advance);
					}
				}
			}
		}
			
	}

	/*
	 * public static void main(String[] args) { InvoiceDataModel invoiceDataModel =
	 * new InvoiceDataModel(); Advance advance = new Advance();
	 * advance.setAdvance_deductee_pan("PQRS"); advance.setAdvance_section("ABCD");
	 * advance.setAdvance_amount(100);
	 * 
	 * Advance advance1 = new Advance(); advance1.setAdvance_deductee_pan("PQRS");
	 * advance1.setAdvance_section("ABCD"); advance1.setAdvance_amount(100);
	 * 
	 * Invoice in = new Invoice(); in.setInvoice_advance_deductee_pan("PQRS");
	 * in.setInvoice_line_item_actual_tds_section("ABCD");
	 * in.setInvoice_line_item_tds_amount(100); List<Advance> ad= new
	 * ArrayList<Advance>(); List<Invoice> ins= new ArrayList<Invoice>();
	 * ad.add(advance); ad.add(advance1); ins.add(in);
	 * invoiceDataModel.setAdvances(ad); invoiceDataModel.setInvoices(ins);
	 * System.out.println(advanceDeducteeAndAdvanceSection(invoiceDataModel)); }
	 */

}
